import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';

interface Alumno {
  ncontrol: string;
  nombre: string;
  semestre: number;
  nacimiento: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  listaAlumnos = signal<Alumno[]>([]);

  nuevoAlumno: Alumno = {ncontrol:"", nombre:"", semestre :1, nacimiento:""}

  mostrarModel = false;

  abrirModal() {
    this.mostrarModel = true;
  }

  cancelar() {
    this.nuevoAlumno = {ncontrol:"", nombre:"", semestre :1, nacimiento:""};
    this.mostrarModel = false;
  }

  aceptar() {
    if (this.nuevoAlumno.ncontrol && this.nuevoAlumno.nombre){
      this.listaAlumnos.update(lista => [...lista, {...this.nuevoAlumno}]);
      this.cancelar();
    }
  }
}


