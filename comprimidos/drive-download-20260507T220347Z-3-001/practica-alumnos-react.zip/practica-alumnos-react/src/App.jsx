import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [lista, setLista] = useState([])
  const [modal, setModal] = useState(false)
  const [form, setForm] = useState({ ncontrol:'', nombre: '', semestre: 1, nacimiento:'' })

  const manejarCambio = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const aceptar = () => {
    if (form.ncontrol && form.nombre){
      setLista([...lista, form])
      cancelar()
    }
  }

  const cancelar = () => {
    setForm({ ncontrol:'', nombre: '', semestre: 1, nacimiento:'' })
    setModal(false)
  }

  return (
    <div className="container mt-5">
      <h2>Control de Alumnos - React</h2>
      <button className='btn btn-primary mb-3' onClick={() => setModal(true)}>Nuevo Registro</button>

      <table className='table'>
        <thead>
          <tr>
            <th>N. Control</th>
            <th>Nombre</th>
            <th>Semestre</th>
            <th>Nacimiento</th>
          </tr>
        </thead>
        <tbody>
          {lista.map((al, i) => (
            <tr key={i}>
              <td>{al.ncontrol}</td>
              <td>{al.nombre}</td>
              <td>{al.semestre}</td>
              <td>{al.nacimiento}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {modal && (
        <div className='modal d-block' style={{background: 'rgba(0,0,0,0.5)'}}>
          <div className='modal-dialog'>
            <div className='modal-content'>
              <div className='modal-body'>
                <input name='ncontrol' value={form.ncontrol} onChange={manejarCambio} className='form-control mb-2' placeholder='No. Control' />
                <input name='nombre' value={form.nombre} onChange={manejarCambio} className='form-control mb-2' placeholder='Nombre' />
                <input name='semestre' type='number' value={form.semestre} onChange={manejarCambio} className='form-control mb-2' />
                <input name='nacimiento' type='date' value={form.nacimiento} onChange={manejarCambio} className='form-control mb-2' />
                <div>
                  <div className='modal-footer'>
                    <button className='btn btn-secondary' onClick={cancelar}>Cancelar</button>
                    <button className='btn btn-success' onClick={aceptar}>Aceptar</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default App