import { Component, computed, inject, OnInit, signal } from '@angular/core';
import { TablaUsuarios } from './components/tabla-usuarios/tabla-usuarios';
import { ModalUsuario } from './components/modal-usuario/modal-usuario';
import { User, UserService } from './services/user';
import autoTable from 'jspdf-autotable';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TablaUsuarios, ModalUsuario],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit{
  private userService = inject(UserService)

  user = signal<User[]>([])
  selectedUsers = signal<User[]>([])

  verModal = false
  usuarioEdicion: User = {name:"", email:"", password:"", avatar:"https://i.imgur.com/LDOO4Qs.jpg"}
  
  filtroNombre = signal("")
  filtroEmail = signal("")

  usuariosFiltrados = computed(() => {
    return this.user().filter(u => 
      u.name.toLowerCase().includes(this.filtroNombre().toLowerCase()) &&
      u.email.toLowerCase().includes(this.filtroEmail().toLowerCase())
    )
  })

  ngOnInit() { this.cargarUsuarios(); }

  cargarUsuarios(){
    this.userService.getAll().subscribe(res => this.user.set(res))
  }

  abrirNuevo() {
    this.usuarioEdicion = { name: '', email: '', password: '', avatar: 'https://i.imgur.com/LDOO4Qs.jpg'}
    this.verModal = true
  }

  prepararEdicion(user: User) {
    this.usuarioEdicion = { ...user }
    this.verModal = true
  }

  guardar(user: User) {
    if (user.id) {
      this.userService.update(user.id, user).subscribe(res => {
        this.user.update(list => list.map(u => u.id === res.id ? res : u))
        this.verModal = false
      })
       } else {
      this.userService.create(user).subscribe(res => {
        this.user.update(list => [res, ...list])
        this.verModal = false
      })
    }
  }

  eliminar(id: number) {
    this.userService.delete(id).subscribe(() => {
      this.user.update(list => list.filter(u => u.id !== id))
      this.selectedUsers.update(list => list.filter(u => u.id !== id))
    })
  }

  manejarFiltro(event: {campo: string, valor: string}) {
    if (event.campo === 'name') this.filtroNombre.set(event.valor)
    if (event.campo === 'email') this.filtroEmail.set(event.valor)
  }

  manejarCheck(event: {user: User, checked: boolean}) {
    if (event.checked) {
      this.selectedUsers.update(l => [...l, event.user])
    } else {
      this.selectedUsers.update(l => l.filter(u => u.id !== event.user.id))
    }
  }

  manejarSelectAll(checked: boolean) {
    if (checked) this.selectedUsers.set([...this.usuariosFiltrados()])
    else this.selectedUsers.set([])
  }

  generarPDF() {
    const doc = new jsPDF()
    doc.setFontSize(18)
    doc.text('Reporte de Alumnos - Tecnológico Nacional de México', 14, 20)
    doc.setFontSize(12)
    doc.text('Campus San Juan del Río', 14, 28)
    
    const datos = this.selectedUsers().map(u => [u.id, u.name, u.email]);
    
    autoTable(doc, {
      startY:35,
      head:[["ID","Nombre","Correo"]],
      body:datos,
      theme:"grid",
      headStyles:{fillColor:[27,57,106]}
    });
    doc.save('alumnos_sjr.pdf');
  }
}
