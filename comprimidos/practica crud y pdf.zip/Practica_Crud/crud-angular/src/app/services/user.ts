import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

export interface User{
  id?: number
  name: string
  email: string
  password?: string
  avatar: string
}

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private http = inject(HttpClient)
  private url = "https://api.escuelajs.co/api/v1/users"

  getAll() { return this.http.get<User[]>(this.url)}
  create(user: User) { return this.http.post<User>(this.url, user)}
  update(id: number, user: User) { return this.http.put<User>(`$(this.url)/${id}`,user)}
  delete(id: number) { return this.http.delete(`${this.url}/${id}`)}
}