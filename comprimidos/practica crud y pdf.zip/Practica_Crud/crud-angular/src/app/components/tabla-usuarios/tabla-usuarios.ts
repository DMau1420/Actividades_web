import { Component, EventEmitter, Input, Output } from '@angular/core';
import { User } from '../../services/user';

@Component({
  selector: 'app-tabla-usuarios',
  standalone: true,
  imports: [],
  templateUrl: './tabla-usuarios.html',
  styleUrl: './tabla-usuarios.css',
})
export class TablaUsuarios {
  @Input() usuarios: User[] = [];
  @Input() seleccionados: User[] = [];

  @Output() onEditar = new EventEmitter<User>();
  @Output() onEliminar = new EventEmitter<number>();
  @Output() onToggleCheck = new EventEmitter<{user: User, checked: boolean}>();
  @Output() onSelectAll = new EventEmitter<boolean>();
  @Output() onFiltrar = new EventEmitter<{campo: string, valor: string}>();

  estaSeleccionado(id: number | undefined): boolean{
    return this.seleccionados.some(u => u.id === id)
  }
}
