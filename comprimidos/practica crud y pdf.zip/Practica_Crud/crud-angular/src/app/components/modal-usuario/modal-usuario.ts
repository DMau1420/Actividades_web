import { Component, EventEmitter, Input, Output } from '@angular/core';
import { User } from '../../services/user';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-modal-usuario',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './modal-usuario.html',
  styleUrl: './modal-usuario.css',
})
export class ModalUsuario {
  @Input() usuarioTemp!: User
  @Output() onGuardar = new EventEmitter<User>()
  @Output() onCancelar = new EventEmitter<void>()

}