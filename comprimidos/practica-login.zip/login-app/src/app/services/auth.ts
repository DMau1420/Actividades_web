import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable, signal } from '@angular/core';
import { tap } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private http = inject(HttpClient)
  private apiUrl = "https://api.escuelajs.co/api/v1/auth"

  currentUser = signal<any>(null)

  login(email: string, password: string){
    return this.http.post<any>(`${this.apiUrl}/login`, {email, password}).pipe(
      tap(respuesta =>{
        localStorage.setItem("token", respuesta.access_token)
      })
    )
  }

  getProfile(){
    const token = localStorage.getItem("token")
    const headers = new HttpHeaders({"Authorization": `Bearer ${token}`})

    return this.http.get<any>(`${this.apiUrl}/profile`, {headers}).pipe(
      tap(usuario => this.currentUser.set(usuario))
    )
  }

  logout(){
    localStorage.removeItem("token")
    this.currentUser.set(null)
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem("token")
  }
}
