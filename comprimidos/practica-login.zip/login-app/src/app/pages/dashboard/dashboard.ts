import { Component, inject, OnInit } from '@angular/core';
import { AuthService } from '../../services/auth';
import { RouteConfigLoadEnd, Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  imports: [],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class DashboardComponent implements OnInit {
  authService = inject(AuthService)
  private router = inject(Router)

  ngOnInit() {
    this.authService.getProfile().subscribe({
      error:() => {
        this.salir()
      }
    })
  }
  salir(){
    this.authService.logout()
    this.router.navigate(["/login"])
  }
}
