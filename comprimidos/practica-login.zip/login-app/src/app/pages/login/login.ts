import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class LoginComponent {
  private authService = inject(AuthService)
  private router = inject(Router)

  email = "john@mail.com"
  password = "changeme"
  error = false

  iniciarSesion(){
    this.authService.login(this.email, this.password).subscribe({
      next: () => {
        this.router.navigate(["/dashboard"])
      },
      error: () => this.error = true
    })
  }
}
