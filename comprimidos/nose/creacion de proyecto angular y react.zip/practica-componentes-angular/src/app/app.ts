import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from './header/header';  // Importa desde la carpeta header
import { Nav } from './nav/nav';          // Importa desde la carpeta nav
import { Footer } from './footer/footer'; // Importa desde la carpeta footer

@Component({
  selector: 'app-root',
  imports: [Header, Nav, Footer],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('practica-componentes-angular');
}