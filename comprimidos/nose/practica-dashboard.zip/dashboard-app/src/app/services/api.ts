import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';

export interface Producto {
  id: number;
  title: string;
  price: number;
  category: { name: string };
  images: string[];
}

@Injectable({
  providedIn: 'root',
})
export class ApiService {
  private http = inject(HttpClient);
  private url = 'https://api.escuelajs.co/api/v1/products?offset=0&limit=5';

  // Obtenemos 5 productos para el carrusel y la tabla
  getProductos() {
    return this.http.get<Producto[]>(this.url);
  }
}
