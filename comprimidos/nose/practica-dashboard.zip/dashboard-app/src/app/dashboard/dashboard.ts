import { Component, inject, OnInit } from '@angular/core';
import { ApiService, Producto } from '../services/api';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { BaseChartDirective } from 'ng2-charts';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, BaseChartDirective],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class DashboardComponent {
  private apiService = inject(ApiService);
  
  productos: Producto[] = [];
  mensajeFormulario = '';

  // Configuración de la Gráfica de Barras
  barChartData = {
    labels: ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo'],
    datasets: [
      { data: [65, 59, 80, 81, 56], label: 'Ventas Mensuales', backgroundColor: '#2c3e50' }
    ]
  }

  ngOnInit() {
    this.apiService.getProductos().subscribe(res => {
      this.productos = res;
    })
  }

  enviarMensaje() {
    alert('Mensaje enviado al equipo: ' + this.mensajeFormulario);
    this.mensajeFormulario = '';
  }

  descargarPDF(){
    const data = document.getElementById('dashboard-content');
    if (data) {
      html2canvas(data).then(canvas =>{
        const imgWidth = 208;
        const pageHeight = 295;
        const imgHeight = canvas.height * imgWidth / canvas.width;
        const contentDataURL = canvas.toDataURL('image/png');
        const pdf = new jsPDF('p', 'mm', 'a4');
        pdf.addImage(contentDataURL, 'PNG', 0, 0, imgWidth, imgHeight);
        pdf.save('Dashboard_Reporte.pdf');
      });
    }
  }
}