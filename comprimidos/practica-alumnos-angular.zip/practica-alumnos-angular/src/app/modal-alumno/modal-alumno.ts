import { Component, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Alumno } from '../app';

@Component({
  selector: 'app-modal-alumno',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './modal-alumno.html',
  styleUrl: './modal-alumno.css',
})
export class ModalAlumno {
  onAceptar = output<Alumno>();
  onCancelar = output<void>();

  nuevoAlumno: Alumno = { ncontrol: "", nombre: "", semestre: 1, nacimiento: "" };

  cancelar() {
    this.onCancelar.emit(); // Solo cierra
  }

  aceptar() {
    if (this.nuevoAlumno.ncontrol && this.nuevoAlumno.nombre) {
      this.onAceptar.emit({ ...this.nuevoAlumno }); // Envía los datos
    }
  }
}