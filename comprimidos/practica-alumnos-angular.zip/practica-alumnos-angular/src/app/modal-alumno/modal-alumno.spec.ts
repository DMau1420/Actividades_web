import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalAlumno } from './modal-alumno';

describe('ModalAlumno', () => {
  let component: ModalAlumno;
  let fixture: ComponentFixture<ModalAlumno>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ModalAlumno]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ModalAlumno);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
