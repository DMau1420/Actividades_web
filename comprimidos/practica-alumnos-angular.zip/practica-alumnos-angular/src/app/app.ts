import { Component, signal } from '@angular/core';
import { ModalAlumno } from './modal-alumno/modal-alumno';
import { TablaAlumno } from './tabla-alumno/tabla-alumno';

export interface Alumno {
  ncontrol: string;
  nombre: string;
  semestre: number;
  nacimiento: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TablaAlumno, ModalAlumno],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  listaAlumnos = signal<Alumno[]>([]);

  mostrarModel = signal(false);

  registrar(alumno: Alumno){
    this.listaAlumnos.update(lista => [...lista,alumno]);
    this.mostrarModel.set(false)
  }
}


