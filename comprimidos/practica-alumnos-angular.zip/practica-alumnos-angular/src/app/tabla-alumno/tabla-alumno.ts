import { Component, input } from '@angular/core';
import { Alumno } from '../app';

@Component({
  selector: 'app-tabla-alumno',
  standalone: true,
  imports: [],
  templateUrl: './tabla-alumno.html',
  styleUrl: './tabla-alumno.css',
})
export class TablaAlumno {
  alumno = input.required<Alumno[]>();
}
