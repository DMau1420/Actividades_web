import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TablaAlumno } from './tabla-alumno';

describe('TablaAlumno', () => {
  let component: TablaAlumno;
  let fixture: ComponentFixture<TablaAlumno>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [TablaAlumno]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TablaAlumno);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
